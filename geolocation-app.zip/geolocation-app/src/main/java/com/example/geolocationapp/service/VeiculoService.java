package com.example.geolocationapp.service;

import com.example.geolocationapp.model.Veiculo;
import com.example.geolocationapp.repository.VeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VeiculoService {

    @Autowired
    private VeiculoRepository repository;

    public VeiculoService(VeiculoRepository repository) {
        this.repository = repository;
    }

    public Veiculo cadastrarVeiculo(Veiculo veiculo) {
        return repository.save(veiculo);
    }

    public List<Veiculo> listarVeiculos() {
        return repository.findAll();
    }

    public void removerVeiculo(Long id) {
        repository.deleteById(id);
    }
}
