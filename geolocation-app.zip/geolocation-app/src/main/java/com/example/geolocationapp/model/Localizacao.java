package com.example.geolocationapp.model;

import javax.persistence.*;

//jpa e hibernate para comunicação/mapeamento com banco de dados
@Entity
@Table(name = "localizacao")
public class Localizacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "latitude", nullable = false)
    private String latitude;

    @Column(name = "longitude", nullable = false)
    private String longitude;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_veiculo", nullable = false)
    private Veiculo veiculo;

    public Localizacao(){}

    public Localizacao(Long id, String latitude, String longitude, Veiculo veiculo) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.veiculo = veiculo;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Veiculo getVeiculos() {
        return veiculo;
    }

    public void setVeiculos(Veiculo veiculo) {
        this.veiculo = veiculo;
    }
}
