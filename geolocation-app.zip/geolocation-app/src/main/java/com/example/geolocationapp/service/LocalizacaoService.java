package com.example.geolocationapp.service;

import com.example.geolocationapp.model.Localizacao;
import com.example.geolocationapp.repository.LocalizacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocalizacaoService {

    @Autowired
    private LocalizacaoRepository repository;

    public LocalizacaoService(LocalizacaoRepository repository) {
        this.repository = repository;
    }

    public Localizacao cadastrarLocalizacao(Localizacao localizacao) {
        return repository.save(localizacao);
    }

    public List<Localizacao> listarLocalizacoes() {
        return repository.findAll();
    }

    public void removerLocalizacao(Long id) {
        repository.deleteById(id);
    }
}
