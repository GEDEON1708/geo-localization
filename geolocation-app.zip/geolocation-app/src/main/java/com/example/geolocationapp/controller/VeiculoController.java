package com.example.geolocationapp.controller;

import com.example.geolocationapp.model.Veiculo;
import com.example.geolocationapp.service.VeiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/veiculos")
public class VeiculoController {

    @Autowired
    private final VeiculoService service;

    public VeiculoController(VeiculoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Veiculo> cadastrarVeiculo(@RequestBody Veiculo veiculo) {
        Veiculo vaiculoSalvo = service.cadastrarVeiculo(veiculo);
        return new ResponseEntity<>(vaiculoSalvo, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Veiculo>> listarVeiculos() {
        List<Veiculo> veiculos = service.listarVeiculos();
        return new ResponseEntity<>(veiculos, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarVeiculo(@PathVariable Long id) {
        service.removerVeiculo(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
