package com.example.geolocationapp.controller;

import com.example.geolocationapp.model.Localizacao;
import com.example.geolocationapp.model.Veiculo;
import com.example.geolocationapp.service.LocalizacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/localizacao")
public class LocalizacaoConroller {

    @Autowired
    private LocalizacaoService service;

    public LocalizacaoConroller(LocalizacaoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Localizacao> cadastrarLocalizacao(@RequestBody Localizacao localizacao) {
        Localizacao vaiculoSalvo = service.cadastrarLocalizacao(localizacao);
        return new ResponseEntity<>(vaiculoSalvo, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Localizacao>> listarLocalizacao() {
        List<Localizacao> veiculos = service.listarLocalizacoes();
        return new ResponseEntity<>(veiculos, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarLocalizacao(@PathVariable Long id) {
        service.removerLocalizacao(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
