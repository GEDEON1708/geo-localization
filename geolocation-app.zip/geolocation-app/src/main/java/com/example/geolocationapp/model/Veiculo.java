package com.example.geolocationapp.model;

import javax.persistence.*;

@Entity
@Table(name = "veiculo")
public class Veiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "placa", nullable = false)
    private String placa;

    @Column(name = "modelo", nullable = false)
    private String modelo;

    @Column(name = "ano_de_fabricacao", nullable = false)
    private String anoDeFacricacao;

    public Veiculo(){}

    public Veiculo(Long id, String placa, String modelo, String anoDeFacricacao) {
        this.id = id;
        this.placa = placa;
        this.modelo = modelo;
        this.anoDeFacricacao = anoDeFacricacao;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnoDeFacricacao() {
        return anoDeFacricacao;
    }

    public void setAnoDeFacricacao(String anoDeFacricacao) {
        this.anoDeFacricacao = anoDeFacricacao;
    }
}
