package com.example.geolocationapp;

public class Constants {

    public static String jwtKey = "Ky2jU2dLSIAcyuLzkQAu";
    public static String jwtIssuer = "myApp";
}
