package com.example.geolocationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeolocationAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
